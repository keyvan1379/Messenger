create trigger MESS_TIG
  before insert
  on MESSAGE
  for each row
BEGIN
    SELECT mess_seq.nextval
    INTO :new.M_ID
    FROM dual;
    END;
/

