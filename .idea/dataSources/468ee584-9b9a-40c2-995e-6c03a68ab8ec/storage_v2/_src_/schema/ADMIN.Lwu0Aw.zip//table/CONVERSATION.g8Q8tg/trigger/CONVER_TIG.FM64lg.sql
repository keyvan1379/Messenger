create trigger CONVER_TIG
  before insert
  on CONVERSATION
  for each row
BEGIN
    SELECT conver_seq.nextval
    INTO :new.C_ID
    FROM dual;
    END;
/

